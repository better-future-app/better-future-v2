import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  Image,
  ImageBackground,
  Dimensions,
  ToastAndroid,
} from "react-native";
import AsyncStorage from "@react-native-community/async-storage";
import InfoCard from "../components/InfoCard";
import {
  TextInput,
  ScrollView,
  TouchableOpacity,
} from "react-native-gesture-handler";
import { LinearGradient } from "expo-linear-gradient";
import externalStyle from "./styleSheet";
import {
  LineChart,
  BarChart,
  PieChart,
  ProgressChart,
  ContributionGraph,
  StackedBarChart,
} from "react-native-chart-kit";
import { debounce } from "lodash";
import SearchBarInfoCard from "../components/Searchbar";

const Favourite = () => {
  /////////////////////////////////////////////////////////
  // search data /////////////////////////////////////////
  const search = async (value, storeInState = true) => {
    if (value) {
      console.log("searching", value);
      const searchResponse = await fetch(
        `https://esgstock1.azurewebsites.net/search?q=${value}`
      );
      const searchData = await searchResponse.json();
      if (storeInState) {
        if (searchData == null) {
          setSearchData(["NO RESULT"]);
          console.log("null");
        } else setSearchData(searchData);
      } else {
        return searchData;
      }

      // console.log(searchData);
    }
  };

  // const [isSearching, setIsSearching] = useState(false);
  const searchHandle = useCallback(debounce(search, 500), []); //this is a fucntion

  const saveinstorage = async (value) => {
    setaddbuttonactivity(false);
    setresultdisplay(true);
    setplaceholder("Search");
    setaddbuttondisplay("add");

    AsyncStorage.setItem(`numShares${selectedStock}`, String(value));
    var message = selectedStock.concat(" is in your invested stock");
    ToastAndroid.showWithGravityAndOffset(
      message,
      ToastAndroid.LONG,
      ToastAndroid.BOTTOM,
      40,
      5
    );
  };

  const onChangeText = (value) => {
    console.log(value);
    if (resultdisplay) {
      if (value.length > 1) {
        searchHandle(value);
        // setIsSearching(true);
      } else {
        searchHandle.cancel();
        // setIsSearching(false);
        setSearchData([]);
      }
    }

    // setSearchData(value);
  };
  const [searchData, setSearchData] = useState([]);

  ///////////////////////////////////////////////////////////////////
  ////////////////add stock status////////////////////////////////
  const [addbuttonactivity, setaddbuttonactivity] = useState(false);
  const [addbuttondisplay, setaddbuttondisplay] = useState("add");

  const addstockbutton = () => {
    if (addbuttonactivity) {
      setaddbuttonactivity(false);
      setaddbuttondisplay("add");
      console.log(addbuttonactivity);
    } else {
      setaddbuttonactivity(true);
      setaddbuttondisplay("cancel");
      console.log(addbuttonactivity);
    }
  };
  ////////////////////////////////////////////////////////////////
  ///////////remove result if selected////////////////////////////
  const [resultdisplay, setresultdisplay] = useState(true);

  ////////////////////////////////////////////////////////////////
  ///////////////////select stock ///////////////////////////////
  const [selectedStock, setSelectedStock] = useState();
  const [placeholder, setplaceholder] = useState("Search");
  const addstock = (stock) => {
    setSelectedStock(stock);
    setplaceholder("Number of Stock");
    console.log(stock);
    setresultdisplay(false);
    setSearchData([]);
  };

  //////////////////////////////////////////////////////
  ////////////getting invested stocks /////////////////////////////
  const [investedsocks, setInvestedStocks] = useState([]);
  const updateInvestedStock = async () => {
    try {
      const keys = await AsyncStorage.getAllKeys();
      //console.log("here are the keys");
      //console.log(keys);

      const allinvestedsocks = await Promise.all(
        keys.map(async (item) => {
          if (item.substring(0, 9) == "numShares") {
            console.log(item.substring(9));
            const data = await search(item.substring(9), false);
            return data.length > 0 ? data[0] : null;
          } else {
            console.log(item, "is not in invested stock");
          }
        })
      ).then(function (values) {
        return values.filter(function (value) {
          return typeof value !== "undefined";
        });
      });
      console.log("allinvestedsocks", allinvestedsocks);
      setInvestedStocks(allinvestedsocks);
    } catch (error) {
      // Error retrieving data
      console.log(error.message);
    }
  };
  useEffect(() => {
    updateInvestedStock();

    // Subscribe for the focus Listener
    // const unsubscribe = navigation.addListener("focus", updateInvestedStock);
    // return () => {
    //   unsubscribe();
    // };
  }, []);

  return (
    <ScrollView
      vertical
      showsHorizontalScrollIndicator={false}
      style={{ paddingBottom: 0 }}
    >
      <View style={externalStyle.header}>
        <View style={externalStyle.more_buttom}>
          <Text style={externalStyle.header_text}>Investment</Text>
        </View>
      </View>
      {addbuttonactivity ? (
        <View></View>
      ) : (
        <View>
          <LineChart
            data={{
              labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
              datasets: [
                {
                  data: [
                    Math.random() * 100,
                    Math.random() * 100,
                    Math.random() * 100,
                    0,
                    null,
                    null,
                    null,
                    null,
                  ],
                },
              ],
            }}
            width={Dimensions.get("window").width - 20} // from react-native
            height={300}
            withInnerLines={false}
            withOuterLines={false}
            yAxisLabel="$"
            yAxisInterval={1} // optional, defaults to 1
            chartConfig={{
              backgroundColor: "#ffffff",
              backgroundGradientFrom: "#ffffff",
              backgroundGradientTo: "#ffffff",
              decimalPlaces: 2, // optional, defaults to 2dp
              color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
            }}
            bezier
            style={{
              padding: 10,
              borderRadius: 16,
              marginBottom: -10,
            }}
          />
        </View>
      )}

      <View
        style={{
          flexDirection: "row",
          paddingHorizontal: 20,
          width: "100%",
          paddingTop: 20,
          alignItems: "center",
        }}
      >
        <View style={{ width: "50%" }}>
          <Text
            style={{
              fontWeight: "bold",
              fontSize: 17,
              color: "#585a61",
            }}
          >
            Invested Stock
          </Text>
        </View>
        <View style={{ width: "50%", alignItems: "flex-end" }}>
          <View style={externalStyle.more_buttom}>
            <TouchableOpacity onPress={() => addstockbutton()}>
              <Text
                style={{
                  fontWeight: "bold",
                  fontSize: 13,
                  color: "#FFF",
                }}
              >
                {addbuttondisplay}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      {addbuttonactivity ? (
        <View>
          <View
            style={{
              backgroundColor: "#FFF",
              paddingVertical: 8,
              paddingHorizontal: 20,
              marginHorizontal: 25,
              borderRadius: 15,
              marginTop: 25,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <TextInput
              placeholder={placeholder}
              placeholderTextColor="#b1e5d3"
              style={externalStyle.home_input}
              // onChangeText={(text) => onChangeText(text)}
              onChangeText={(text) => onChangeText(text)}
              onSubmitEditing={({ nativeEvent: { text } }) => {
                console.log("Text value on press enter: ", text);
                saveinstorage(text);
              }}
            />

            <Image
              source={require("../images/3.png")}
              style={{ height: 20, width: 20, paddingLeft: 20 }}
            />
          </View>
          {resultdisplay ? (
            searchData.slice(0, 5).map((item, index) => (
              <SearchBarInfoCard
                stock={item.name || item.company}
                ticker={item.ticker || item.stockticker}
                esgrating={item.esgrating}
                industry={item.group}
                esgwarning={item.rating}
                key={index}
                onPress={() => {
                  // setSelectedStock(item.name);
                  addstock(item.name);
                  // setSearchData([]);
                }}
              />
            ))
          ) : (
            <View></View>
          )}
        </View>
      ) : (
        <View></View>
      )}
      <View>
        {addbuttonactivity ? (
          <View></View>
        ) : (
          <View style={{ paddingTop: 15 }}>
            {investedsocks.map((item, index) => (
              <InfoCard
                stock={item.name || item.company}
                ticker={item.ticker || item.stockticker}
                esgrating={item.esgrating}
                industry={item.group}
                esgwarning={item.rating}
                key={index}
              />
            ))}
          </View>
        )}
      </View>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ paddingBottom: 0 }}
      >
        <View></View>
      </ScrollView>
    </ScrollView>
  );
};
export default Favourite;
