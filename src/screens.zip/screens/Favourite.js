import React from 'react'
import {View, Text} from 'react-native'

const Favourite = () => {
    return(
        <View style={{
            justifyContent:"center",
            alignContent:"center",
            flex:1
        }}>
            <Text>Favourite</Text>
        </View>
    )
}
export default Favourite;